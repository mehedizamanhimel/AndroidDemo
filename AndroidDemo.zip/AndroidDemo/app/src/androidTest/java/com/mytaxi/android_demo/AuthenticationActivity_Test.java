package com.mytaxi.android_demo;


import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.mytaxi.android_demo.activities.AuthenticatedActivity;
import com.mytaxi.android_demo.activities.AuthenticationActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

@RunWith(AndroidJUnit4.class)
public class AuthenticationActivity_Test {

    @Rule
    public ActivityTestRule<AuthenticationActivity> activityRule
            = new ActivityTestRule<>(AuthenticationActivity.class);


    @Test
    public void loginTest_Positive(){
        onView(withId(R.id.edt_username))
                .perform(typeText("asdasdf"), closeSoftKeyboard());
        onView(withId(R.id.edt_password))
                .perform(typeText("sdfasdfsdf"), closeSoftKeyboard());

    }

}
