package com.mytaxi.android_demo;


import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.mytaxi.android_demo.activities.AuthenticatedActivity;
import com.mytaxi.android_demo.activities.MainActivity;

import org.junit.Rule;
import org.junit.runner.RunWith;

import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner;

@RunWith(AndroidJUnit4.class)
public class AuthenticatedActivity_Test {

    @Rule
    public ActivityTestRule<AuthenticatedActivity> activityRule
            = new ActivityTestRule<>(AuthenticatedActivity.class);




}
