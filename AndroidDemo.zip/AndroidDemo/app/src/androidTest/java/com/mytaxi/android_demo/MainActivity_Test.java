package com.mytaxi.android_demo;

public class MainActivity_Test {
}
