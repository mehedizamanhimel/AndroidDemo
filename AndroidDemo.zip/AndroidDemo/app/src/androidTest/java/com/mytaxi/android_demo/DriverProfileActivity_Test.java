package com.mytaxi.android_demo;


import android.support.test.runner.AndroidJUnit4;

import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class DriverProfileActivity_Test {



}
